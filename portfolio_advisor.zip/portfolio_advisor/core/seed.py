"""Demo data seeding — creates a demo consultant login and a few sample
clients so the app is usable immediately, with no manual setup step.

Called both from the CLI (`scripts/seed_demo_data.py`, for local use) and
automatically from `Home.py` on startup. This matters for hosted
deployments (e.g. Streamlit Community Cloud) where there's no shell access
to run a one-off script before the app starts — the app has to seed itself.
Safe to call on every startup: it only creates records that don't already
exist.
"""

from core.auth.auth import hash_password
from core.db import crud
from core.db.session import get_session, init_db

DEMO_USERNAME = "demo"
DEMO_PASSWORD = "demo1234"

SAMPLE_CLIENTS = [
    dict(
        name="Priya Shah",
        email="priya@example.com",
        risk_tolerance="conservative",
        investment_horizon_years=6,
        initial_investment=250_000,
        max_position_weight=0.30,
        esg_focus=False,
        excluded_tickers="",
        notes="Nearing retirement; prioritizes capital preservation.",
    ),
    dict(
        name="Daniel Okafor",
        email="daniel@example.com",
        risk_tolerance="moderate",
        investment_horizon_years=15,
        initial_investment=500_000,
        max_position_weight=0.35,
        esg_focus=True,
        excluded_tickers="",
        notes="Wants an ESG-screened core allocation.",
    ),
    dict(
        name="Wei Chen",
        email="wei@example.com",
        risk_tolerance="aggressive",
        investment_horizon_years=25,
        initial_investment=100_000,
        max_position_weight=0.40,
        esg_focus=False,
        excluded_tickers="HYG",
        notes="Long horizon, comfortable with volatility. No high-yield credit exposure per mandate.",
    ),
    dict(
        name="Amara Bello",
        email="amara@example.com",
        risk_tolerance="custom",
        target_risk=0.09,
        investment_horizon_years=10,
        initial_investment=350_000,
        max_position_weight=0.30,
        esg_focus=False,
        excluded_tickers="",
        notes="Targeting a specific volatility band agreed with the client.",
    ),
]


def seed(verbose: bool = False) -> None:
    init_db()
    db = get_session()
    try:
        consultant = crud.get_consultant_by_username(db, DEMO_USERNAME)
        if consultant is None:
            consultant = crud.create_consultant(
                db, DEMO_USERNAME, "Demo Consultant", hash_password(DEMO_PASSWORD),
                email="demo@investelity.app", firm_name="Investelity Advisory (Demo)",
            )
            if verbose:
                print(f"Created consultant '{DEMO_USERNAME}' / password '{DEMO_PASSWORD}'")
        elif verbose:
            print(f"Consultant '{DEMO_USERNAME}' already exists — skipping.")

        existing_names = {c.name for c in crud.list_clients(db, consultant.id)}
        for fields in SAMPLE_CLIENTS:
            if fields["name"] in existing_names:
                if verbose:
                    print(f"Client '{fields['name']}' already exists — skipping.")
                continue
            crud.create_client(db, consultant.id, **fields)
            if verbose:
                print(f"Created client '{fields['name']}'")
    finally:
        db.close()
