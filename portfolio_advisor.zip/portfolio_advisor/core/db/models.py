"""SQLAlchemy models for the practice-management layer.

This is the "organizing software" part of the app: each consultant has a
roster of clients, each client carries saved risk preferences/constraints,
and every portfolio the app generates and saves is kept as a dated record
so a consultant can pull up a client's recommendation history.
"""

from datetime import datetime, timezone

from sqlalchemy import (
    Boolean,
    DateTime,
    Float,
    ForeignKey,
    Integer,
    String,
    Text,
)
from sqlalchemy.orm import DeclarativeBase, Mapped, mapped_column, relationship


class Base(DeclarativeBase):
    pass


def _now() -> datetime:
    return datetime.now(timezone.utc)


class Consultant(Base):
    __tablename__ = "consultants"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    username: Mapped[str] = mapped_column(String(64), unique=True, index=True)
    name: Mapped[str] = mapped_column(String(128))
    email: Mapped[str] = mapped_column(String(128), default="")
    password_hash: Mapped[str] = mapped_column(String(256))
    firm_name: Mapped[str] = mapped_column(String(128), default="")
    created_at: Mapped[datetime] = mapped_column(DateTime, default=_now)

    clients: Mapped[list["Client"]] = relationship(back_populates="consultant", cascade="all, delete-orphan")


class Client(Base):
    __tablename__ = "clients"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    consultant_id: Mapped[int] = mapped_column(ForeignKey("consultants.id"), index=True)
    name: Mapped[str] = mapped_column(String(128))
    email: Mapped[str] = mapped_column(String(128), default="")
    created_at: Mapped[datetime] = mapped_column(DateTime, default=_now)

    # Preferences / constraints used to generate portfolios
    risk_tolerance: Mapped[str] = mapped_column(String(32), default="moderate")  # conservative/moderate/aggressive/custom
    target_risk: Mapped[float | None] = mapped_column(Float, nullable=True)  # used when risk_tolerance == custom
    investment_horizon_years: Mapped[int] = mapped_column(Integer, default=10)
    initial_investment: Mapped[float] = mapped_column(Float, default=0.0)
    max_position_weight: Mapped[float] = mapped_column(Float, default=0.35)
    esg_focus: Mapped[bool] = mapped_column(Boolean, default=False)
    excluded_tickers: Mapped[str] = mapped_column(Text, default="")  # comma-separated
    notes: Mapped[str] = mapped_column(Text, default="")

    consultant: Mapped["Consultant"] = relationship(back_populates="clients")
    portfolios: Mapped[list["Portfolio"]] = relationship(back_populates="client", cascade="all, delete-orphan")

    def excluded_tickers_list(self) -> list[str]:
        return [t.strip().upper() for t in self.excluded_tickers.split(",") if t.strip()]


class Portfolio(Base):
    __tablename__ = "portfolios"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    client_id: Mapped[int] = mapped_column(ForeignKey("clients.id"), index=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=_now)
    label: Mapped[str] = mapped_column(String(128), default="")
    strategy: Mapped[str] = mapped_column(String(64))
    data_as_of: Mapped[str] = mapped_column(String(128), default="")

    expected_return: Mapped[float] = mapped_column(Float)
    expected_risk: Mapped[float] = mapped_column(Float)
    sharpe_ratio: Mapped[float] = mapped_column(Float)

    client: Mapped["Client"] = relationship(back_populates="portfolios")
    holdings: Mapped[list["PortfolioHolding"]] = relationship(back_populates="portfolio", cascade="all, delete-orphan")


class PortfolioHolding(Base):
    __tablename__ = "portfolio_holdings"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    portfolio_id: Mapped[int] = mapped_column(ForeignKey("portfolios.id"), index=True)
    ticker: Mapped[str] = mapped_column(String(16))
    name: Mapped[str] = mapped_column(String(128), default="")
    asset_class: Mapped[str] = mapped_column(String(64), default="")
    weight: Mapped[float] = mapped_column(Float)

    portfolio: Mapped["Portfolio"] = relationship(back_populates="holdings")
